document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('youtube-form');
    const videoContainer = document.getElementById('video-container');

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        // Pata link ya YouTube kutoka kwa input
        const youtubeLink = document.getElementById('youtube-link').value;

        // Chuja ID ya video kutoka kwa link ya YouTube
        const videoId = extractYouTubeId(youtubeLink);

        if (videoId) {
            // Unda iframe ili kuonyesha video
            videoContainer.innerHTML = `
                <iframe 
                    src="https://www.youtube.com/embed/${videoId}" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            `;
        } else {
            videoContainer.innerHTML = '<p style="color: red;">Tafadhali weka link halali ya YouTube.</p>';
        }
    });

    // Function ya kuchuja ID ya video kutoka kwa link ya YouTube
    function extractYouTubeId(url) {
        const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
        const match = url.match(regex);
        return match ? match[1] : null;
    }
});