const express = require('express');
const multer = require('multer');
const path = require('path');
const app = express();

// Set storage engine for uploaded videos
const storage = multer.diskStorage({
    destination: './uploads/',
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    },
});

// Initialize upload
const upload = multer({
    storage,
    fileFilter: (req, file, cb) => {
        const filetypes = /mp4|mov|avi|mkv/;
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = filetypes.test(file.mimetype);

        if (extname && mimetype) {
            return cb(null, true);
        } else {
            cb('Error: Faili ya video pekee inaruhusiwa!');
        }
    },
}).single('video');

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploaded files statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Upload route
app.post('/upload', (req, res) => {
    upload(req, res, (err) => {
        if (err) {
            return res.status(400).json({ message: err });
        }

        if (!req.file) {
            return res.status(400).json({ message: 'Hakuna faili iliyopakiwa!' });
        }

        // Save metadata to database (example only)
        const videoMetadata = {
            title: req.body.title,
            description: req.body.description,
            filePath: `/uploads/${req.file.filename}`,
        };

        console.log('Video Metadata:', videoMetadata);

        return res.status(200).json({
            message: 'Video imepakiwa kwa mafanikio!',
            video: videoMetadata,
        });
    });
});

// Start server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server inaendesha kwenye http://localhost:${PORT}`));